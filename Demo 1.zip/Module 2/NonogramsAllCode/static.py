

rows = 0
cols = 0

def setVariables(numrows,numcols):
    global rows, cols
    rows, cols = numrows, numcols
