
constantPos = []
lengths = []
orientations = []
numCars =0
directions = 4

def setVariables( constantPos1, orientations1, lengths1, numCars1):
    global constantPos, orientations, lengths, numCars
    constantPos = constantPos1
    lengths = lengths1
    orientations = orientations1
    numCars = numCars1
